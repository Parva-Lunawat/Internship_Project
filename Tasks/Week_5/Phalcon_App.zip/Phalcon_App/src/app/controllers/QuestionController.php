<?php

use Phalcon\Mvc\Controller;

class QuestionController extends Controller
{
    public function indexAction()
    {
        $this->view->polls = Polls::all();
    }
    public function createAction()
    {
        if ($this->request->isPost()) {
            $title = $this->request->getPost("title");
            $options = $this->request->getPost("options");
            Polls::create($title, array_filter($options));
            return $this->response->redirect("/question");
        }
    }
    public function viewAction($pollId)
    {
        $this->view->poll = Polls::find($pollId);
    }
    public function voteAction($pollId, $optionId)
    {
        Polls::vote($pollId, $optionId);
        return $this->response->redirect("/question/view/" . $pollId);
    }
}
