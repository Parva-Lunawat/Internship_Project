<?php
require_once __DIR__ . '/../vendor/autoload.php';

use Phalcon\Di\FactoryDefault;
use Phalcon\Mvc\Application;
use Phalcon\Autoload\Loader;
use Phalcon\Mvc\View;
ini_set('display_errors', 1);
error_reporting(E_ALL);

$di = new FactoryDefault();

\Phalcon\Di\Di::setDefault($di);

// Autoload
$loader = new Loader();
$loader->setDirectories([
    __DIR__ . '/../app/controllers/',
    __DIR__ . '/../app/models/',
]);
$loader->register();

// Register view service
$di->set('view', function () {
    $view = new View();
    $view->setViewsDir(__DIR__ . '/../app/views/');
    return $view;
});

$app = new Application($di);

echo $app->handle($_SERVER["REQUEST_URI"])->getContent();